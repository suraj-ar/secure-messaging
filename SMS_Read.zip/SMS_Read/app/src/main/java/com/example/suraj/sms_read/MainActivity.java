package com.example.suraj.sms_read;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Vector;

public class MainActivity extends AppCompatActivity {

    private EditText name;
    private EditText pw;
    private TextView info;
    private Button login;
    private int counter=5;
    private Vector<String> messages;
    private BroadcastReceiver broadcastReceiver;
    private VigenereCipher cipher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.RECEIVE_SMS},1);


        name=(EditText)findViewById(R.id.etName);
        pw=(EditText)findViewById(R.id.etPw);
        info=(TextView)findViewById(R.id.tvInfo);
        login=(Button)findViewById(R.id.btLogin);
        messages = new Vector<>();
        cipher = new VigenereCipher();

        broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                VigenereCipher vigenereCipher = new VigenereCipher();
                if (intent.getAction().equals("android.provider.Telephony.SMS_RECEIVED")){
                    //Toast.makeText(context,"HEY THIS IS SURAJ",Toast.LENGTH_LONG).show();
                    Bundle bundle = intent.getExtras();
                    SmsMessage[] smsMessages = null;
                    String smsFrom;
                    //Resources resources = new Resources();
                    if(bundle != null){
                        Object[] objects = (Object[])bundle.get("pdus");
                        smsMessages = new SmsMessage[objects.length];
                        for (int i = 0; i < smsMessages.length; i++) {
                            smsMessages[i] = SmsMessage.createFromPdu((byte[])objects[i]);
                            smsFrom = smsMessages[i].getOriginatingAddress();
                            String msgBody = vigenereCipher.decrypt(smsMessages[i].getMessageBody(),"SURAJ");
                            Toast.makeText(context,msgBody +"    ",Toast.LENGTH_LONG).show();
                            messages.add(msgBody);

                            //resources.messages.add(msgBody);
                            //resources.from.add(smsFrom);
                        }
                    }

                }
            }
        };

        MainActivity.this.registerReceiver(broadcastReceiver,new IntentFilter("android.provider.Telephony.SMS_RECEIVED"));
        info.setText("No. of attempts remaining :- 5");

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                validate(name.getText().toString(),pw.getText().toString());
            }
        });
    }
    private void validate(String username,String password)
    {
        if((username.equals("sssipher"))&& (password.equals("123")))
        {
            Intent intent=new Intent(MainActivity.this,disp.class);

            intent.putExtra("MESSAGES",messages.toString() );
            startActivity(intent);

        }
        else
        {
            counter--;
            info.setText("No. of attempts remaining ="+String.valueOf(counter));
        }
        if (counter==0)
        {
            login.setEnabled(false);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1 && permissions.length >0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
            Toast.makeText(MainActivity.this,"PERMISSION GRANTED",Toast.LENGTH_LONG).show();
        }
    }
}
