package com.example.suraj.sms_read;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.widget.Toast;

public class MyReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO: This method is called when the BroadcastReceiver is receiving
        // an Intent broadcast.
        VigenereCipher vigenereCipher = new VigenereCipher();
        if (intent.getAction().equals("android.provider.Telephony.SMS_RECEIVED")){
            //Toast.makeText(context,"HEY THIS IS SURAJ",Toast.LENGTH_LONG).show();
            Bundle bundle = intent.getExtras();
            SmsMessage[] smsMessages = null;
            String smsFrom;
            //Resources resources = new Resources();
            if(bundle != null){
                Object[] objects = (Object[])bundle.get("pdus");
                smsMessages = new SmsMessage[objects.length];
                for (int i = 0; i < smsMessages.length; i++) {
                    smsMessages[i] = SmsMessage.createFromPdu((byte[])objects[i]);
                    smsFrom = smsMessages[i].getOriginatingAddress();
                    String msgBody = vigenereCipher.decrypt(smsMessages[i].getMessageBody(),"SURAJ");
                    Toast.makeText(context,msgBody +"    ",Toast.LENGTH_LONG).show();
                    //resources.messages.add(msgBody);
                    //resources.from.add(smsFrom);
                }
            }

        }
    }
}
