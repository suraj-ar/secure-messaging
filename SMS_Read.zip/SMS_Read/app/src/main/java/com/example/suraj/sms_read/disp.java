package com.example.suraj.sms_read;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class disp extends AppCompatActivity {


    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_disp);
        listView = findViewById(R.id.listView);

        Intent intent = getIntent();
        String s = intent.getStringExtra("MESSAGES");
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(disp.this,android.R.layout.simple_expandable_list_item_1,s.split(","));
        listView.setAdapter(arrayAdapter);



    }
}
