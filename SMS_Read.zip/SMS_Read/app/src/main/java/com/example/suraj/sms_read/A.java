package com.example.suraj.sms_read;

/**
 * Created by Suraj on 06-04-2018.
 */

import java.io.DataInputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.util.Random;
import java.io.*;
/**
 * Created by Suraj on 06-04-2018.
 */

import java.math.BigInteger;
import java.util.Random;
import java.io.*;
class VigenereCipher
{

    public static String encrypt(String text, final String key)

    {

        String res = "";
        String result="";
        text = text.toUpperCase();

        for (int i = 0, j = 0; i < text.length(); i++)

        {

            char c = text.charAt(i);

            if (c < 'A' || c > 'Z')

                continue;

            res += (char) ((c + key.charAt(j) - 2 * 'A') % 26 + 'A');

            j = ++j % key.length();

        }

        //return res;
        for (int i=0; i<res.length(); i++)
        {
            if (Character.isUpperCase(res.charAt(i)))
            {
                char ch = (char)(((int)res.charAt(i) +
                        3 - 65) % 26 + 65);
                result=result+ch;
            }
            else
            {
                char ch = (char)(((int)res.charAt(i) +
                        3 - 97) % 26 + 97);
                result=result+ch;
            }
        }
        return result;

    }



    public static String decrypt(String text, final String key)

    {

        String res = "";

        text = text.toUpperCase();

        for (int i = 0, j = 0; i < text.length(); i++)

        {

            char c = text.charAt(i);

            if (c < 'A' || c > 'Z')

                continue;

            res += (char) ((c - key.charAt(j) + 26) % 26 + 'A');

            j = ++j % key.length();

        }

        return res;

    }

}